# 🎓 MEAN Stack CRUD — Finals Lab Activity 6

**Student Management System** using MongoDB, Express.js, Angular 19, and Node.js

---

## 📁 Project Structure

```
mean-finals/
├── api/
│   ├── index.js          ← Express + MongoDB backend
│   └── package.json
└── ui/
    └── mean-crud/        ← Angular 19 frontend
        └── src/app/
            ├── app.component.ts    ← CRUD logic
            ├── app.component.html  ← UI template
            ├── app.component.css   ← Styling
            ├── app.config.ts
            └── app.routes.ts
```

---

## ⚙️ Setup Instructions

### Step 1 — MongoDB Setup
1. Create folder `C:\data\db`
2. Run `mongod.exe`
3. Open MongoDB Compass → Connect to `mongodb://localhost:27017`
4. Create database: `mean_finals_db`
5. Create collection: `students`

### Step 2 — API Setup
```bash
cd E:\mean-finals\api
npm init -y
npm install express --save
npm install cors
npm install mongodb@4.1.0 --save
npm install multer --save
# Copy index.js from this repo
node index.js
```
✅ Server runs at `http://localhost:3000`

### Step 3 — Angular UI Setup
```bash
cd E:\mean-finals\ui
ng new mean-crud --standalone --routing=true --style=css
cd mean-crud
# Replace src/app files with files from this repo
ng serve
```
✅ App runs at `http://localhost:4200`

---

## ✨ Features

| Feature | Status |
|---|---|
| View all students | ✅ |
| Add new student | ✅ |
| **Edit student** | ✅ |
| Delete student | ✅ |
| **Email field** (added) | ✅ |
| **Contact number field** (added) | ✅ |
| Custom CSS styling | ✅ |
| MongoDB integration | ✅ |

---

## 🗃️ Student Data Model

```json
{
  "name": "Juan Dela Cruz",
  "studentId": "2024-00123",
  "course": "BSIT",
  "year": "2nd Year",
  "email": "juan@school.edu.ph",
  "contact": "09XX-XXX-XXXX"
}
```

---

## 🔗 API Endpoints

| Method | Route | Description |
|---|---|---|
| GET | `/students` | Get all students |
| GET | `/students/:id` | Get single student |
| POST | `/students` | Add new student |
| PUT | `/students/:id` | Update student |
| DELETE | `/students/:id` | Delete student |

---

## 📸 Reflection

**What I learned:**
- How to connect MongoDB to a Node.js/Express backend
- How Angular services and HttpClient communicate with a REST API
- How to implement full CRUD operations in a MEAN stack
- How to use Angular standalone components with FormsModule

**Challenges faced:**
- Configuring CORS between Angular (port 4200) and Express (port 3000)
- Using MongoDB ObjectId for document identification
- Managing Angular reactive forms with two-way data binding

---

*Finals Lab Activity 6 · MEAN Stack · 6AWEB2526*
