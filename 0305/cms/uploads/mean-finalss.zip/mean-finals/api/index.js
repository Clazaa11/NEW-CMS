const express = require('express');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');
const multer = require('multer');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri);

let db;
let studentsCollection;

async function connectDB() {
  try {
    await client.connect();
    db = client.db("mean_finals_db");
    studentsCollection = db.collection("students");
    console.log("✅ Connected to MongoDB successfully!");
  } catch (err) {
    console.error("❌ MongoDB connection error:", err);
  }
}

connectDB();

// GET all students
app.get('/students', async (req, res) => {
  try {
    const students = await studentsCollection.find({}).toArray();
    res.json(students);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single student by ID
app.get('/students/:id', async (req, res) => {
  try {
    const student = await studentsCollection.findOne({ _id: new ObjectId(req.params.id) });
    if (!student) return res.status(404).json({ error: 'Student not found' });
    res.json(student);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST - Add new student
app.post('/students', async (req, res) => {
  try {
    const { name, studentId, course, year, email, contact } = req.body;
    if (!name || !studentId || !course || !year || !email || !contact) {
      return res.status(400).json({ error: 'All fields are required' });
    }
    const newStudent = {
      name,
      studentId,
      course,
      year,
      email,
      contact,
      createdAt: new Date()
    };
    const result = await studentsCollection.insertOne(newStudent);
    res.status(201).json({ ...newStudent, _id: result.insertedId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT - Update student
app.put('/students/:id', async (req, res) => {
  try {
    const { name, studentId, course, year, email, contact } = req.body;
    const updatedStudent = {
      name,
      studentId,
      course,
      year,
      email,
      contact,
      updatedAt: new Date()
    };
    const result = await studentsCollection.updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: updatedStudent }
    );
    if (result.matchedCount === 0) return res.status(404).json({ error: 'Student not found' });
    res.json({ message: 'Student updated successfully', ...updatedStudent });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE - Remove student
app.delete('/students/:id', async (req, res) => {
  try {
    const result = await studentsCollection.deleteOne({ _id: new ObjectId(req.params.id) });
    if (result.deletedCount === 0) return res.status(404).json({ error: 'Student not found' });
    res.json({ message: 'Student deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(port, () => {
  console.log(`🚀 Express server running at http://localhost:${port}`);
});
