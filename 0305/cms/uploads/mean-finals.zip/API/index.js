const express = require('express');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');
const multer = require('multer');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const upload = multer();

// MongoDB connection
const url = 'mongodb://localhost:27017';
const dbName = 'MyDb';
let db;

MongoClient.connect(url, { useUnifiedTopology: true })
  .then(client => {
    console.log('✅ Connected to MongoDB');
    db = client.db(dbName);
  })
  .catch(err => {
    console.error('❌ MongoDB connection error:', err);
  });

// =====================
//   ROUTES
// =====================

// GET all books
app.get('/books', async (req, res) => {
  try {
    const books = await db.collection('Books').find().toArray();
    res.json(books);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single book by ID
app.get('/books/:id', async (req, res) => {
  try {
    const book = await db.collection('Books').findOne({ _id: new ObjectId(req.params.id) });
    if (!book) return res.status(404).json({ error: 'Book not found' });
    res.json(book);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST - Add new book
app.post('/books', upload.none(), async (req, res) => {
  try {
    const { title, author, genre, price } = req.body;
    if (!title || !author) {
      return res.status(400).json({ error: 'Title and author are required' });
    }
    const newBook = {
      title,
      author,
      genre: genre || '',
      price: price ? parseFloat(price) : 0,
      createdAt: new Date()
    };
    const result = await db.collection('Books').insertOne(newBook);
    res.status(201).json({ message: 'Book added successfully', id: result.insertedId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT - Update book
app.put('/books/:id', upload.none(), async (req, res) => {
  try {
    const { title, author, genre, price } = req.body;
    const updatedBook = {
      title,
      author,
      genre: genre || '',
      price: price ? parseFloat(price) : 0,
      updatedAt: new Date()
    };
    const result = await db.collection('Books').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: updatedBook }
    );
    if (result.matchedCount === 0) return res.status(404).json({ error: 'Book not found' });
    res.json({ message: 'Book updated successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE - Remove book
app.delete('/books/:id', async (req, res) => {
  try {
    const result = await db.collection('Books').deleteOne({ _id: new ObjectId(req.params.id) });
    if (result.deletedCount === 0) return res.status(404).json({ error: 'Book not found' });
    res.json({ message: 'Book deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start server
app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
