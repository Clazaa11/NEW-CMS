import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BookService, Book } from './book.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  books: Book[] = [];
  newBook: Book = { title: '', author: '', genre: '', price: 0 };
  editBook: Book | null = null;
  editId: string = '';
  message: string = '';
  isError: boolean = false;

  constructor(private bookService: BookService) {}

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.bookService.getBooks().subscribe({
      next: (data) => this.books = data,
      error: (err) => this.showMessage('Failed to load books: ' + err.message, true)
    });
  }

  addBook(): void {
    if (!this.newBook.title || !this.newBook.author) {
      this.showMessage('Title and Author are required!', true);
      return;
    }
    this.bookService.addBook(this.newBook).subscribe({
      next: () => {
        this.showMessage('Book added successfully!', false);
        this.newBook = { title: '', author: '', genre: '', price: 0 };
        this.loadBooks();
      },
      error: (err) => this.showMessage('Error adding book: ' + err.message, true)
    });
  }

  startEdit(book: Book): void {
    this.editId = book._id!;
    this.editBook = { ...book };
  }

  saveEdit(): void {
    if (!this.editBook) return;
    this.bookService.updateBook(this.editId, this.editBook).subscribe({
      next: () => {
        this.showMessage('Book updated successfully!', false);
        this.editBook = null;
        this.editId = '';
        this.loadBooks();
      },
      error: (err) => this.showMessage('Error updating book: ' + err.message, true)
    });
  }

  cancelEdit(): void {
    this.editBook = null;
    this.editId = '';
  }

  deleteBook(id: string): void {
    if (!confirm('Are you sure you want to delete this book?')) return;
    this.bookService.deleteBook(id).subscribe({
      next: () => {
        this.showMessage('Book deleted successfully!', false);
        this.loadBooks();
      },
      error: (err) => this.showMessage('Error deleting book: ' + err.message, true)
    });
  }

  showMessage(msg: string, isError: boolean): void {
    this.message = msg;
    this.isError = isError;
    setTimeout(() => this.message = '', 3000);
  }
}
