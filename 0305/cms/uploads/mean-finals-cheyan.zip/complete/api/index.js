const express = require('express');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri);
let studentsCollection;

async function connectDB() {
  await client.connect();
  const db = client.db("mean_finals_db");
  studentsCollection = db.collection("students");
  console.log("✅ Connected to MongoDB!");
}
connectDB();

app.get('/students', async (req, res) => {
  try {
    const students = await studentsCollection.find({}).toArray();
    res.json(students);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/students', async (req, res) => {
  try {
    const result = await studentsCollection.insertOne(req.body);
    res.json(result);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.put('/students/:id', async (req, res) => {
  try {
    const { _id, ...updateData } = req.body;
    const result = await studentsCollection.updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: updateData }
    );
    console.log('Update result:', result);
    res.json({ message: 'Updated!', result });
  } catch(e) {
    console.log('Update error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.delete('/students/:id', async (req, res) => {
  try {
    await studentsCollection.deleteOne({ _id: new ObjectId(req.params.id) });
    res.json({ message: 'Deleted!' });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.listen(port, () => console.log(`🚀 Server running at http://localhost:${port}`));
